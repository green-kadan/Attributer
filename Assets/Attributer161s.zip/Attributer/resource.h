﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ で生成されたインクルード ファイル。
// AttrShlExt.rc で使用
//
#define IDS_PROJNAME                    100
#define IDR_ATTRSHLEXT                  101
#define IDD_ATTRIBUTER                  102
#define IDD_ATTRIBUTER78                103
#define IDC_ITEMICON                    201
#define IDC_ITEMNAME                    202
#define IDC_GROUP_TIMESTAMP             203
#define IDC_RECT_TIMESTAMP              204
#define IDC_CHECK_CREATION              205
#define IDC_CHECK_WRITE                 206
#define IDC_CHECK_ACCESS                207
#define IDC_CHECK_PRINT                 208
#define IDC_CHECK_EDIT                  209
#define IDC_DTP_CREATION_DATE           210
#define IDC_DTP_WRITE_DATE              211
#define IDC_DTP_ACCESS_DATE             212
#define IDC_DTP_PRINT_DATE              213
#define IDC_GROUP_EDIT                  214
#define IDC_RECT_EDIT                   215
#define IDC_ITEMEDIT                    216
#define IDC_EDIT_EDIT                   217
#define IDC_SPIN_EDIT                   218
#define IDC_DTP_CREATION_TIME           219
#define IDC_DTP_WRITE_TIME              220
#define IDC_DTP_ACCESS_TIME             221
#define IDC_DTP_PRINT_TIME              222
#define IDC_DTP_EDIT_TIME               223
#define IDC_CHECK_SAME                  224
#define IDC_CHECK_PRINT_CLEAR           225
#define IDC_CHECK_EDIT_CLEAR            226
#define IDC_GROUP_ATTRIBUTE             227
#define IDC_RECT_ATTRIBUTE              228
#define IDC_CHECK_READONLY              229
#define IDC_CHECK_HIDDEN                230
#define IDC_CHECK_ARCHIVE               231
#define IDC_CHECK_INDEX                 232
#define IDC_CHECK_SYSTEM                233
#define IDC_GROUP_FOLDER                234
#define IDC_RECT_FOLDER                 235
#define IDC_CHECK_FOLDER                236
#define IDC_CHECK_FILE                  237
#define IDC_GROUP_FILE                  238
#define IDC_RECT_FILE                   239
#define IDC_CHECK_ZONE                  240
#define IDS_TABNAME                     301
#define IDS_MULTIPLE_TYPES              302
#define IDS_LOG_FILENAME                303
#define IDS_MESSAGE_COMPLEMENT          311
#define IDS_E_ABORT                     401
#define IDS_E_ACCESSDENIED              402
#define IDS_E_FAIL                      403
#define IDS_E_HANDLE                    404
#define IDS_E_INVALIDARG                405
#define IDS_E_NOINTERFACE               406
#define IDS_E_NOTIMPL                   407
#define IDS_E_OUTOFMEMORY               408
#define IDS_E_POINTER                   409
#define IDS_E_UNEXPECTED                410
#define ID_SAME_CREATION                32769
#define ID_SAME_WRITE                   32770
#define ID_SET_TIME_AM                  32771
#define ID_SET_TIME_PM                  32772
#define ID_OVERWRITE_CREATION           32773
#define ID_OVERWRITE_WRITE              32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        241
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         241
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
